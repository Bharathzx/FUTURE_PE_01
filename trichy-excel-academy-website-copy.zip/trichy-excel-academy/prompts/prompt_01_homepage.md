# Prompt 1 — Homepage Copy

## Purpose
Generates the full homepage copy for a local business website: headline, sub-headline, introduction, and trust stats.

## Prompt Template

```
You are an expert conversion copywriter for local businesses in India.

Generate homepage website copy for a [BUSINESS_TYPE] called "[BUSINESS_NAME]" 
located in [CITY], [STATE].

Business details:
- Years in operation: [YEARS]
- Target audience: [TARGET_AUDIENCE]
- Key differentiators: [3–5 UNIQUE POINTS, comma-separated]
- Tone: [friendly / professional / confident-yet-approachable]

Generate the following sections:

1. HEADLINE (max 12 words)
   - Clear value proposition
   - Outcome-focused, not feature-focused
   - Avoid passive voice

2. SUB-HEADLINE (1 sentence, max 25 words)
   - Who it's for + the primary benefit
   - Include one specific proof point (number, year, stat) if available

3. INTRO SECTION (2–3 short paragraphs)
   - Paragraph 1: What the business does and who it serves
   - Paragraph 2: What makes this business different (the "why us")
   - Paragraph 3: Social proof or origin story (keep it human)

4. TRUST STATS (4 items, each: number + short label)
   - Use real or realistic stats provided by the business
   - Labels: max 4 words

Rules:
- No jargon or filler phrases ("world-class", "one-stop solution", "best in class")
- Every sentence must pass the "So what?" test from the customer's perspective
- Write in second person (you/your) wherever possible
- Keep sentences under 20 words each
- Tone must stay consistent across all sections
```

## Variables to Replace

| Variable | Example |
|----------|---------|
| `[BUSINESS_TYPE]` | coaching institute |
| `[BUSINESS_NAME]` | Excel Academy |
| `[CITY]` | Tiruchirappalli |
| `[STATE]` | Tamil Nadu |
| `[YEARS]` | 13 |
| `[TARGET_AUDIENCE]` | Class 11–12 students and TNPSC aspirants |
| `[3–5 UNIQUE POINTS]` | small batches, daily doubt sessions, bilingual faculty, parent reports |
| `[TONE]` | confident-yet-approachable |

## Follow-up Prompt (optional)

```
Rewrite the headline in 3 alternative versions. Each should:
- Lead with a different emotional hook (aspiration / fear of missing out / curiosity)
- Stay under 12 words
- Avoid repeating words from the original headline
```
