# Prompt 2 — Services Page Copy

## Purpose
Generates individual service descriptions with names, inclusions, pricing, and a "why choose this" differentiator block.

## Prompt Template

```
You are a website copywriter specialising in local service businesses in India.

Write a services page for "[BUSINESS_NAME]", a [BUSINESS_TYPE] in [CITY].

List of services offered:
- [SERVICE_1]
- [SERVICE_2]
- [SERVICE_3]
(Add more lines as needed)

Pricing information (if available):
- [SERVICE_1]: [PRICE_RANGE]
- [SERVICE_2]: [PRICE_RANGE]
(Leave blank if not applicable — write "Contact for pricing" instead)

Target audience: [TARGET_AUDIENCE]
Tone: [TONE]

Generate the following:

SECTION A — Services Page Opening (2 sentences max)
- One line on what the business offers overall
- One line on who it's designed for

SECTION B — Service Cards (one card per service)
For each service, write:
  - Service Name: 3–5 words
  - Description: 1–2 sentences describing what's included (not just what it is)
  - Price: as provided, or "Contact us for pricing"
  - Choose This If: one short sentence — the customer's specific situation that makes this the right option

SECTION C — Why Choose Us (differentiator block)
- Opening line: 1 sentence
- 3–4 bullet points, each starting with a benefit (not a feature)
- Closing reassurance line: 1 sentence

Rules:
- Descriptions must say what's INCLUDED, not just name the service
- No hyperbole ("best", "unmatched", "revolutionary")
- Price transparency builds trust — include it wherever possible
- Each "Choose This If" line should make the reader feel seen
```

## Variables to Replace

| Variable | Example |
|----------|---------|
| `[BUSINESS_NAME]` | Excel Academy |
| `[BUSINESS_TYPE]` | competitive exam coaching institute |
| `[CITY]` | Tiruchirappalli |
| `[SERVICE_1]` | NEET Coaching |
| `[PRICE_RANGE]` | ₹42,000/year |
| `[TARGET_AUDIENCE]` | Class 11–12 students and working professionals preparing for TNPSC |
| `[TONE]` | confident but simple |

## Follow-up Prompt (optional)

```
Now write a comparison table for the 3 most popular services showing:
columns: Service Name | Duration | Batch Size | Includes | Starting Price | Best For
Keep each cell under 8 words. Format as a markdown table.
```
