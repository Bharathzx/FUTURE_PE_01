# Prompt 4 — Tone Adaptation Meta-Prompt

## Purpose
Reuses copy written for one business type and adapts it — vocabulary, sentence rhythm, emotional register, and trust signals — for a completely different business type. This makes the entire framework reusable across clients.

## Prompt Template

```
You are a senior brand copywriter. Rewrite the following website copy for a new 
business type, adapting the tone without changing the underlying structure.

ORIGINAL BUSINESS TYPE: [e.g., coaching institute]
NEW BUSINESS TYPE: [e.g., hair salon]

TONE SHIFT REQUIRED:
- Original tone: [e.g., confident, motivational, outcome-driven]
- New tone: [e.g., warm, friendly, sensory, personal]

Adapt the following dimensions:

1. VOCABULARY
   - Original uses: [e.g., academic terms, outcome metrics]
   - New should use: [e.g., sensory language, personal/emotional words]

2. SENTENCE LENGTH
   - Original: [e.g., medium, structured]
   - New: [e.g., short, punchy, even sentence fragments for rhythm]

3. TRUST SIGNALS
   - Original: [e.g., success rates, years in operation, certifications]
   - New: [e.g., customer reviews, Instagram-worthy results, stylist experience]

4. EMOTIONAL REGISTER
   - Original: [e.g., aspirational, competitive drive]
   - New: [e.g., relaxed confidence, self-care, feel-good]

5. CTA STYLE
   - Original: [e.g., "Reserve your seat", urgency-based]
   - New: [e.g., "Book your slot", invitation-based, no pressure]

ORIGINAL COPY TO REWRITE:
---
[PASTE COPY SECTIONS HERE]
---

Output: Rewritten copy only. No explanations. Preserve the section structure 
(headline / sub-headline / intro / CTAs) but transform everything else.
```

## Tone Reference Guide

Use this guide to fill in the adaptation fields above:

| Business Type | Vocabulary | Sentence Length | Trust Signals | Emotional Register |
|--------------|------------|-----------------|---------------|-------------------|
| Coaching institute | Academic outcomes, metrics | Medium, structured | Success rates, years, batch size | Motivational, competitive |
| Salon / spa | Sensory, personal, beauty terms | Short, rhythmic, fragments OK | Reviews, photos, stylist bio | Warm, relaxed, self-care |
| Clinic / hospital | Clinical, reassuring, precise | Longer, thorough | Certifications, patient count, specialists | Calm, authoritative, reassuring |
| Cafe / restaurant | Sensory, casual, atmospheric | Short, punchy | Local sourcing, regulars, ambiance | Leisurely, inviting, nostalgic |
| Agency / freelancer | Results, ROI, business terms | Sharp, punchy | Portfolio, case studies, client logos | Confident, direct, peer-to-peer |

## Example Usage

**Input**: Copy written for Excel Academy (coaching institute)
**Output**: Same structure adapted for a salon called "Glow Studio, Trichy"

Before (coaching):
> "Score Higher. Get Admitted. Build the Future You Deserve."

After (salon):
> "Look Incredible. Feel Like Yourself Again."

The structural function is identical (value proposition headline) but vocabulary, emotion, and rhythm are entirely different.
