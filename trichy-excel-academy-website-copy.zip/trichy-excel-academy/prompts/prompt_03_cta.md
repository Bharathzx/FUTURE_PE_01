# Prompt 3 — CTA (Call-to-Action) Sections

## Purpose
Generates 4 distinct CTA sections covering the full customer journey: initial contact, social proof, urgency, and soft lead capture.

## Prompt Template

```
You are a conversion copywriter. Write 4 call-to-action (CTA) sections for 
"[BUSINESS_NAME]", a [BUSINESS_TYPE] in [CITY], [STATE].

Business context:
- Primary offer: [WHAT YOU WANT VISITORS TO DO — e.g., book a demo class]
- Low-barrier offer: [FREE OFFER — e.g., free 90-min demo / free consultation]
- Scarcity detail (if real): [e.g., only 30 seats per batch / limited slots this month]
- Location details: [ADDRESS, HOURS]
- Phone/contact: [CONTACT_INFO]
- Sample customer result or testimonial: [NAME, RESULT, YEAR]
- Free resource available: [e.g., free NEET prep guide, free site audit PDF]

Tone: [TONE]

Generate one CTA section for each type below:

CTA TYPE 1 — Primary / Booking CTA
- Goal: get the visitor to take the first step
- Use the low-barrier offer to reduce friction
- Headline: max 10 words
- Body: 2–3 sentences
- Button text: max 5 words, starts with an action verb

CTA TYPE 2 — Trust / Social Proof CTA
- Goal: overcome hesitation with real evidence
- Include the testimonial provided, naturally woven in
- Follow with a social proof statement (total students / success rate)
- Headline: max 10 words
- Body: 3–4 sentences (include the quote)
- Button text: max 5 words

CTA TYPE 3 — Urgency / Scarcity CTA
- Goal: prompt action before the visitor leaves or delays
- Use the real scarcity detail (do NOT invent urgency)
- Headline: max 10 words
- Body: 2–3 sentences
- Button text: max 5 words

CTA TYPE 4 — Soft CTA (for undecided visitors)
- Goal: capture the lead without demanding a commitment
- Use the free resource as the offer
- Headline: max 10 words
- Body: 2 sentences
- Button text: max 5 words

Rules:
- No dark patterns (fake countdown timers, false "only 1 seat left" claims)
- Urgency must come from real, specific scarcity
- CTAs should feel helpful, not pushy — the goal is trust FIRST, conversion SECOND
- Use location and local context to make CTAs feel personal, not generic
```

## Variables to Replace

| Variable | Example |
|----------|---------|
| `[BUSINESS_NAME]` | Excel Academy |
| `[BUSINESS_TYPE]` | coaching institute |
| `[CITY]` | Tiruchirappalli |
| `[STATE]` | Tamil Nadu |
| `[PRIMARY OFFER]` | book a demo class |
| `[LOW-BARRIER OFFER]` | free 90-minute demo session |
| `[SCARCITY DETAIL]` | only 30 seats per batch; June batch has 6 remaining |
| `[LOCATION]` | No. 14, VOC Nagar, Woraiyur, Tiruchirappalli |
| `[HOURS]` | 9 AM – 7 PM, Mon–Sat |
| `[TESTIMONIAL]` | Keerthana S., NEET AIR 412, Madras Medical College, 2024 |
| `[FREE RESOURCE]` | NEET 2026 preparation guide PDF |
| `[TONE]` | confident but approachable |
