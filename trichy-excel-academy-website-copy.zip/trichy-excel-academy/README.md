# AI Website Copy Generator — Trichy Excel Academy

**Prompt Engineering Task 1 · Future Interns (2026)**

---

## Business Chosen

**Trichy Excel Academy** — a competitive exam coaching institute located in Woraiyur, Tiruchirappalli, Tamil Nadu.

**Why this business?**
- Coaching institutes serve a high-intent audience (exam aspirants) where copy clarity directly affects enrolment
- Typical website copy for such institutes is generic, lacks social proof, and has weak CTAs
- Strong local market in Trichy with under-served digital presence
- Replicable prompt framework across dozens of similar institutes across India

---

## Prompt Logic

The system uses **4 structured, reusable prompt templates** designed to cover every section of a business website:

| Prompt | Output | Key Design Choice |
|--------|--------|-------------------|
| `prompt_01_homepage.md` | Headline, sub-headline, intro, trust stats | Outcome-first language; "So what?" rule on every sentence |
| `prompt_02_services.md` | Service cards with name, description, price, differentiator | Benefit-first framing; price transparency builds trust |
| `prompt_03_cta.md` | 4 CTA types (booking, trust, urgency, soft) | No fake urgency; uses scarcity only when real |
| `prompt_04_tone_adapter.md` | Meta-prompt to rewrite for any business type | Adjusts vocabulary, sentence length, emotional register |

### Prompt Design Principles

1. **Variable-driven** — every prompt uses `[VARIABLE]` placeholders so it can be reused for any client with a simple find-and-replace
2. **Role-setting** — each prompt opens by assigning Claude a specific expert role ("conversion copywriter", "services page specialist")
3. **Anti-fluff rules** — every prompt explicitly bans filler phrases ("world-class", "one-stop solution") and requires benefit-first writing
4. **Tone control** — tone is a required input, not an afterthought; tested across 5 business types
5. **Output structure** — prompts specify numbered, labelled output sections so the result is immediately usable

---

## Tool Used

- **Claude (claude.ai)** — primary content generation using structured prompts
- **Prompt Engineering approach** — system prompt + role-setting + structured output format + negative constraints

---

## Files

```
trichy-excel-academy/
├── README.md                        ← this file
├── prompts/
│   ├── prompt_01_homepage.md        ← homepage copy prompt
│   ├── prompt_02_services.md        ← services page prompt
│   ├── prompt_03_cta.md             ← CTA sections prompt
│   └── prompt_04_tone_adapter.md    ← tone adaptation meta-prompt
└── outputs/
    ├── output_01_homepage.md        ← generated homepage copy
    ├── output_02_services.md        ← generated services copy
    ├── output_03_cta.md             ← generated CTA copy
    └── output_04_tone_examples.md   ← tone variants (5 business types)
```

---

## How to Reuse for Any Client

1. Open the relevant prompt file
2. Replace all `[VARIABLE]` fields with your client's details
3. Paste into Claude, ChatGPT, or Gemini
4. Review, refine with a follow-up prompt if needed
5. Deliver to client or plug into Framer AI / Lovable

**Time to generate a full website copy set: under 15 minutes per client.**

---

## Results Preview

- **Homepage headline**: "Score Higher. Get Admitted. Build the Future You Deserve."
- **Services**: 6 service cards with pricing, descriptions, differentiators
- **CTAs**: 4 conversion-focused sections covering booking, trust, urgency, and soft lead capture
- **Tone variants**: Coaching · Salon · Clinic · Cafe · Agency

---

*Built as part of Future Interns Prompt Engineering Task 1 · May 2026*
