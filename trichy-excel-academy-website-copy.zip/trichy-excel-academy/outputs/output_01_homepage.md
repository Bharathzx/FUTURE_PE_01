# Output 1 — Homepage Copy
**Business**: Trichy Excel Academy | **Tool**: Claude (claude.ai) | **Prompt**: prompt_01_homepage.md

---

## Headline

**Score Higher. Get Admitted. Build the Future You Deserve.**

---

## Sub-Headline

Trichy's most trusted coaching centre for NEET, JEE, and TNPSC — where 9 out of 10 students clear their exams on the first attempt.

---

## Introduction Section

### Paragraph 1 — What we do

Built for students in Classes 11 & 12, and serious UPSC / TNPSC aspirants across Tiruchirappalli, Karur, and Thanjavur. Excel Academy combines structured classroom learning with personalised guidance — because every student has a different starting point, and deserves a plan built around theirs.

### Paragraph 2 — What makes us different

We don't just teach. We coach, track, correct, and celebrate every milestone with you. Small batches of 30 students mean your doubts get answered in class — not in a queue. Weekly mock tests, daily doubt sessions, and parent progress reports every 15 days keep everyone aligned.

### Paragraph 3 — Social proof / origin

Since 2011, over 4,200 students from Trichy and neighbouring districts have walked through our doors as aspirants and left as achievers. We've stayed in Woraiyur — the same building, the same values — because what works doesn't need to change.

---

## Trust Stats

| Stat | Label |
|------|-------|
| 4,200+ | Students coached |
| 92% | First-attempt success rate |
| 13 yrs | In Tiruchirappalli |
| 38 | Expert faculty members |

---

## Hero CTAs

**Primary**: Book a Free Demo Class
**Secondary**: See Our Results
