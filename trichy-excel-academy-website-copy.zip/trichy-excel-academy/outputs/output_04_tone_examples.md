# Output 4 — Tone Adaptation Examples
**Prompt used**: prompt_04_tone_adapter.md
**Base copy**: Excel Academy (Coaching Institute)
**Purpose**: Demonstrates how the same prompt framework adapts across 5 business types

---

## Tone 1 — Coaching Institute (Original)
**Register**: Confident, motivational, outcome-driven

**Headline**: Score Higher. Get Admitted. Build the Future You Deserve.
**Sub-headline**: Trichy's most trusted NEET & JEE coaching centre — 92% first-attempt success rate since 2011.
**Body**: You've worked hard. You know what you want. What you need is structured guidance, expert faculty, and a team that tracks your progress every single week.
**CTA**: Book a Free Demo Class

*Tone notes: Outcome-focused language ("score higher", "get admitted"). Data-driven trust signals. Urgency through scarcity (limited seats). Clear, direct sentences under 20 words.*

---

## Tone 2 — Salon (Warm & Friendly)
**Register**: Personal, sensory, inviting

**Headline**: Look Incredible. Feel Like Yourself Again.
**Sub-headline**: Trichy's favourite neighbourhood salon — where every visit feels like catching up with a friend who happens to be an expert.
**Body**: Whether it's a big day or just a Tuesday, you deserve to feel your best. Our stylists listen first, then work their magic — no cookie-cutter looks, ever.
**CTA**: Book My Appointment

*Tone notes: Sensory and personal language. Short, rhythmic sentences. Trust comes from vibe and testimonials. CTAs feel like an invitation, not a transaction.*

---

## Tone 3 — Clinic (Calm & Professional)
**Register**: Clinical, reassuring, authoritative

**Headline**: Accurate Diagnosis. Compassionate Care. On Time, Every Time.
**Sub-headline**: Excel Diagnostics — trusted by 15,000+ patients in Tiruchirappalli for reliable reports and specialist consultations.
**Body**: Your health decisions deserve the best information. Our NABL-accredited lab delivers results with clinical precision, and our doctors take the time to explain what they mean.
**CTA**: Book an Appointment

*Tone notes: Measured, thorough sentences. Trust comes from certifications (NABL), patient volume, and specialist credentials. No alarming language. Low-pressure CTAs.*

---

## Tone 4 — Cafe (Casual & Atmospheric)
**Register**: Sensory, leisurely, mood-driven

**Headline**: Your Third Place. Great Coffee. No Rush.
**Sub-headline**: Excel Cafe, Woraiyur — freshly roasted beans, homemade bakes, and a corner table with your name on it.
**Body**: Tiruchirappalli moves fast. Your coffee break shouldn't. Pull up a chair, order your usual, and let the rest wait. We'll be here.
**CTA**: See Our Menu

*Tone notes: Very short sentences, some fragments, for rhythm. Appeals to mood and atmosphere more than features. Pricing rarely mentioned upfront — emotion sells first.*

---

## Tone 5 — Agency (Sharp & Results-Driven)
**Register**: Confident, direct, ROI-focused

**Headline**: We Build Websites That Convert. Not Just Impress.
**Sub-headline**: Excel Digital — a Tiruchirappalli-based web & marketing agency helping local businesses grow revenue online, not just traffic.
**Body**: Vanity metrics are easy to sell. We prefer the ones that matter — enquiries, bookings, sales. If your website isn't working as hard as you are, we should talk.
**CTA**: See Our Work →

*Tone notes: Sharp contrast and reframing ("not just impress", "not just traffic"). Business ROI language. Trust comes from portfolio and results. CTAs have quiet directness.*

---

## Tone Comparison at a Glance

| Dimension | Coaching | Salon | Clinic | Cafe | Agency |
|-----------|----------|-------|--------|------|--------|
| Vocabulary | Academic outcomes | Sensory, personal | Clinical, precise | Atmospheric, casual | Business, ROI |
| Sentence length | Medium | Short, fragments | Longer, thorough | Very short | Sharp, punchy |
| Trust signals | Success rates, years | Reviews, photos | Certifications, patient count | Regulars, ambiance | Portfolio, case studies |
| Emotional hook | Aspiration | Self-care | Reassurance | Leisure | Peer confidence |
| CTA style | Urgency-based | Invitation | Low-pressure | Exploratory | Direct, peer-to-peer |
