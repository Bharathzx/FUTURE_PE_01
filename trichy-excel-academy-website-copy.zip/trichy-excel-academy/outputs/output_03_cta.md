# Output 3 — CTA Sections
**Business**: Trichy Excel Academy | **Tool**: Claude (claude.ai) | **Prompt**: prompt_03_cta.md

---

## CTA 1 — Primary / Booking CTA

**Headline**: Your next rank starts with one free class.

Attend a free 90-minute demo session and see our teaching approach for yourself — no fees, no pressure, no commitment. You'll leave with a clearer picture of what your preparation should look like, whether you enrol with us or not. Seats fill up fast; we accept only 30 students per batch.

**Button**: Reserve Your Free Demo →

---

## CTA 2 — Trust / Social Proof CTA

**Headline**: Students who chose us. Results that speak.

"Excel Academy is the reason I got into Madras Medical College. The faculty identified my weak chapters in Week 1 and built a plan around them — not a generic syllabus." — *Keerthana S., NEET AIR 412, Trichy (2024)*

Join 4,200+ students who chose Excel Academy and never looked back. With a 92% first-attempt success rate across NEET, JEE, and TNPSC, our results aren't a promise — they're a pattern.

**Button**: Talk to an Advisor Today

---

## CTA 3 — Urgency / Scarcity CTA

**Headline**: June 2025 batch: only 6 seats remaining.

Our NEET 2026 morning batch fills every cycle within days — not weeks. We cap each batch at 30 students so every student gets the attention they need. If you've been planning to join, this is the batch to do it.

**Button**: Secure My Seat Now

---

## CTA 4 — Soft CTA (for undecided visitors)

**Headline**: Not ready yet? Take this with you.

Download our free NEET 2026 Preparation Guide — written by our faculty, used by our toppers — and get a clear picture of what your preparation should look like over the next 12 months.

**Button**: Download Free Guide
