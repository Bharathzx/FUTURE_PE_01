# Output 2 — Services Page Copy
**Business**: Trichy Excel Academy | **Tool**: Claude (claude.ai) | **Prompt**: prompt_02_services.md

---

## Services Page Opening

Everything you need to crack your exam — under one roof. From foundation courses to final-stretch crash batches, we have a programme designed for every stage of your preparation.

---

## Service Cards

### 1. NEET Coaching
Full syllabus coverage for Physics, Chemistry & Biology. Includes daily MCQ practice, full-length mock tests every Sunday, and chapter-wise performance tracking.
**Starting price**: ₹42,000 / year
**Choose this if**: You're in Class 11 or 12 and want a structured, year-long NEET preparation plan.

---

### 2. JEE Main & Advanced
Problem-solving methodology, concept-depth sessions, and IIT-level past paper analysis with expert walkthroughs — not just answers, but the thinking behind them.
**Starting price**: ₹48,000 / year
**Choose this if**: You're targeting JEE Main and need to go beyond textbook theory into advanced problem-solving.

---

### 3. TNPSC Group 1 & 2
Tamil Nadu–specific GK, current affairs, and quantitative aptitude — taught in bilingual sessions (Tamil & English) so the language never gets in the way of the learning.
**Starting price**: ₹18,000 / course
**Choose this if**: You're a working professional or graduate preparing for state government services on a fixed timeline.

---

### 4. Crash Batches
90-day intensive revision covering high-weightage topics, full-length mock tests, and strategy sessions for students appearing in the upcoming exam cycle.
**Starting price**: ₹12,000
**Choose this if**: Your exam is in the next 3 months and you need focused, fast-paced revision rather than a full course.

---

### 5. Online Live Classes
Same expert faculty, same curriculum — streamed live with session recordings for revision. Doubt-clearing via dedicated WhatsApp groups and weekly live Q&A.
**Starting price**: ₹28,000 / year
**Choose this if**: You're from outside Trichy or prefer studying from home without compromising on quality.

---

### 6. 1-on-1 Mentoring
Personalised sessions with a subject expert — your weak areas, your pace, your questions. Ideal for students targeting top ranks or needing to recover specific subjects quickly.
**Price**: ₹800 / session
**Choose this if**: You're already enrolled in a batch but need additional targeted support in one or two subjects.

---

## Why Choose Excel Academy

Every programme follows a three-pillar approach: **Teach** the concept clearly, **Test** it immediately, and **Track** student progress week by week.

- **Your doubts are answered same day** — our faculty-to-student ratio stays low by design
- **You always know where you stand** — weekly mock tests with detailed performance breakdowns
- **Your parents stay informed** — progress reports shared every 15 days, no surprises
- **Exam guidance is included** — registration help, college counselling, and strategy sessions at no extra cost

All of this comes with printed study material, monthly parent meetings, and a team that's reachable when you actually need them.
