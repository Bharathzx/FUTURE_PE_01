# Generated Outputs — GlowBar Vitamin C Serum UGC Ad Pack

**Tool**: Claude (claude.ai) | **Prompts**: All 4 templates applied

---

## Output 1 — 6 Hooks

| # | Hook | Trigger | Tone | Audience |
|---|------|---------|------|----------|
| 1 | "I was spending ₹3,000 on foundation every month just to cover my dark spots. Then I tried this." | Pain point (financial) | Confessional | Cold |
| 2 | "Dermatologists have been recommending this ingredient for 20 years. I only found out last month." | Curiosity + authority | Surprised, in-the-know | Cold |
| 3 | "This is what my skin looked like 6 weeks ago. I genuinely did not edit these photos." | Transformation proof | Vulnerable, honest | Warm |
| 4 | "Stop buying expensive salon facials until you fix this one thing at home first." | Contrarian | Direct, slightly bold | Warm |
| 5 | "My mom asked if I got a facial. My cousin asked which filter I was using. Neither. Just this serum." | Social proof + humour | Lighthearted, relatable | Hot |
| 6 | "I almost didn't buy it because I thought vitamin C serums were all the same. Big mistake." | Regret aversion + curiosity | Candid, reflective | Hot |

---

## Output 2 — Ad Scripts

### Script 1 · 30-second Reel · Hook 1 (Pain point)

**[0–3s] HOOK**
"I was spending ₹3,000 on foundation every month just to cover my dark spots. Then I tried this."

**[3–8s] PROBLEM**
"My skin had pigmentation from years of sun exposure and old acne marks. I tried everything — every cream, every face wash. Nothing actually worked."

**[8–18s] SOLUTION**
"This is GlowBar's Vitamin C serum. 15% L-ascorbic acid, no parabens, under ₹600. I started using it every morning, just two drops before sunscreen. Within three weeks, my dull spots were visibly lighter."

**[18–24s] PROOF**
"This is my skin right now. No filter. No ring light tricks. Just my bathroom light and six weeks of consistency."

**[24–30s] CTA**
"Link is in bio. They have a 30-day return policy so there's genuinely nothing to lose. My skin literally can't go back now."

---

### Script 2 · 15-second Story Ad · Hook 5 (Social proof)

**[0–3s] HOOK**
"My mom asked if I got a facial. My cousin asked which filter I was using. Neither."

**[3–10s] SOLUTION**
"GlowBar Vitamin C serum. Two drops every morning. That's the whole routine. Under ₹600 and it actually works."

**[10–15s] CTA**
"Link in bio. Try it for a month."

---

### Script 3 · 60-second YouTube Short / Long Reel · Hook 2 (Curiosity)

**[0–5s] HOOK**
"Dermatologists have been recommending Vitamin C for 20 years. I only found out last month why most Vitamin C serums don't actually work — and what to look for instead."

**[5–20s] PROBLEM**
"Most drugstore vitamin C serums use ascorbyl glucoside — a cheaper form that barely penetrates your skin. I was using one for 8 months and seeing zero results. Turns out, you need L-ascorbic acid at 10–20% concentration. That's the form that actually fades pigmentation."

**[20–40s] SOLUTION**
"GlowBar uses 15% L-ascorbic acid with Vitamin E and ferulic acid — the combination that stabilises it so it doesn't oxidise in your bottle. I've been using it for six weeks. I'll show you my skin in a second — but honestly I was not expecting this."

**[40–52s] PROOF**
"Cheek, forehead, jawline — all the spots that used to bother me. The texture has genuinely smoothed out and my dark spots are way lighter. I'm not a dermatologist. I'm just someone who spent too long buying the wrong products."

**[52–60s] CTA**
"It's under ₹600, cruelty-free, and they ship within 48 hours. Link in bio. And check the ingredient list before you buy any other Vitamin C serum — you'll thank yourself later."

---

## Output 3 — CTA Bank (12 options)

### Group 1 — Low-friction (cold audience)
- "Link is in bio. No pressure — read the reviews and decide for yourself." [spoken / caption]
- "Try it for 30 days. If nothing changes, they'll refund you. No forms, no drama." [spoken / on-screen]
- "Check the before/after photos in my highlights first — then decide." [spoken / caption]

### Group 2 — Urgency (warm audience)
- "They're running a 10% off first order deal right now. Code is in bio." [spoken / on-screen]
- "I wish I'd started using this two years ago. Don't wait like I did." [spoken]
- "Grab it before the next price increase — it's still under ₹600 right now." [spoken / on-screen]

### Group 3 — Social proof (mid-funnel)
- "40,000 people already switched. The reviews are what convinced me to try it." [spoken / caption]
- "4.8 stars across 8,000+ reviews. Read them before you decide — they're what got me." [caption]
- "It sold out twice last quarter. I'm not saying rush, but I am saying check availability." [spoken]

### Group 4 — Soft engagement (organic)
- "Comment 'glow' and I'll send you the link directly." [spoken / caption]
- "Save this if you've been looking for a Vitamin C serum that actually works." [on-screen / caption]
- "DM me if you have oily or dry skin — I'll tell you exactly how I use it for my skin type." [spoken / caption]

---

## Output 4 — Captions

### Caption 1 — Instagram Reel (long-form)

okay real talk — I was about to give up on serums entirely.

I'd tried three different vitamin C products over the past year. All of them promised "brighter skin in 2 weeks." None of them delivered anything except lighter wallets.

Then someone in a skincare group mentioned GlowBar and I figured — fine, one more try.

Six weeks later: my mom thought I got a facial. My cousin thought I was using a filter. I was using neither. Just two drops of this serum every morning before sunscreen.

The difference? It uses 15% L-ascorbic acid — the form that actually works — instead of the cheaper alternatives most brands use.

It's under ₹600. 30-day return policy. Ships in 48 hours.

Link in bio. Try it for a month and then come back and tell me I was wrong.

#skincare #vitaminc #glowbar #ugc #darkspots #indianskin #skincareIndia #serumreview #glowingskin #cleanbeauty #pigmentation #skincareroutine

---

### Caption 2 — Instagram Story / Feed (short)

Spent a year on the wrong vitamin C serums.
One month on GlowBar.
You can see the difference.

Link in bio. First order gets 10% off.

---

### Caption 3 — YouTube Shorts Description

Why most Vitamin C serums don't work (and what to look for instead)

I wasted 8 months on a serum that wasn't doing anything. In this video I break down what changed when I switched to GlowBar's L-ascorbic acid formula — and why the ingredient form actually matters.

Not sponsored. Just a skincare nerd who finally found something that works.

GlowBar Vitamin C Serum → link in description

Timestamps:
0:00 — why I made this video
0:05 — why most vitamin C serums fail
0:20 — what makes GlowBar different
0:40 — my actual skin results (no filter, natural light)
0:52 — where to get it + current offer

---

## Output 5 — Platform Adaptation Guide

| Platform | Best Script | Duration | Key Adjustment |
|----------|-------------|----------|---------------|
| Instagram Reels | Script 1 | 30s | Trending audio, subtitles on, save prompt at end |
| Instagram Stories (paid) | Script 2 | 15s | Link sticker, large text overlay on key claim |
| YouTube Shorts | Script 3 | 60s | Educational tone, keyword in title, timestamps in description |
| Facebook / Meta Ads | Script 1 or 3 | 30–60s | Include price early, mandatory subtitles, low-friction CTA |

### Shoot checklist
- Natural window light only (no ring light — feels more authentic)
- Shoot vertical 9:16
- No heavy colour grading
- Show the actual product clearly for 2+ seconds
- Face on camera for at least the hook
- Real background: bedroom, bathroom, kitchen
- No visible script reading
- Before/after: same phone, same lighting, same angle
