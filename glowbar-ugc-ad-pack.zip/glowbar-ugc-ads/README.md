# UGC Ad Content Pack — GlowBar Vitamin C Serum

**Prompt Engineering Task 2 · Future Interns (2026)**

---

## Product Chosen

**GlowBar Vitamin C Serum** — a D2C skincare brand selling a 15% L-ascorbic acid face serum online in India at ₹599.

**Why this product?**
- High-competition skincare category where authenticity = conversions
- Strong visual proof potential (skin results)
- Clear pain point (dark spots, pigmentation) shared by a large audience
- Price-sensitive Indian D2C market rewards trust-building UGC over polished ads
- Replicable prompt system for any skincare, wellness, or beauty brand

---

## What's Inside

```
glowbar-ugc-ads/
├── README.md
├── prompts/
│   ├── prompt_01_hooks.md           ← 6-hook generator prompt
│   ├── prompt_02_ad_script.md       ← full P→S→P→CTA script prompt
│   ├── prompt_03_cta_bank.md        ← 12 CTA generator prompt
│   └── prompt_04_captions.md        ← multi-platform caption prompt
└── outputs/
    ├── output_01_hooks.md           ← 6 generated hooks
    ├── output_02_scripts.md         ← 3 full ad scripts (15s / 30s / 60s)
    ├── output_03_cta_bank.md        ← 12 CTAs across 4 intent types
    ├── output_04_captions.md        ← 3 captions (Reel / Story / Shorts)
    └── output_05_platform_specs.md  ← platform-specific adaptation guide
```

---

## Prompt Logic

The system is built on 4 structured prompt templates, each targeting a different layer of the UGC content funnel:

| Prompt | Output | Design Principle |
|--------|--------|-----------------|
| `prompt_01_hooks.md` | 6 hooks for cold/warm/hot audiences | Each hook uses a distinct emotional trigger; cold hooks create curiosity, hot hooks drive action |
| `prompt_02_ad_script.md` | Full scripts in P→S→Proof→CTA format | Time-coded sections with word counts calibrated to video duration (2.5 words/sec) |
| `prompt_03_cta_bank.md` | 12 CTAs across 4 intent stages | Explicitly bans generic filler phrases; forces specificity (price, guarantee, result) |
| `prompt_04_captions.md` | 3 captions for 3 platforms | First line doubles as a standalone hook (shown before "more" in feed) |

### Core Design Choices

1. **Anti-brand voice rules** — every prompt explicitly bans buzzwords ("game-changer", "obsessed", "holy grail") to force authentic UGC tone
2. **Audience temperature matching** — hooks 1–2 target cold, 3–4 warm, 5–6 hot audiences
3. **Word count = video duration** — scripts are calibrated at 2.5 words/second so creators can read the word count and know the runtime
4. **Risk-reduction CTAs** — every CTA prompt requires naming the price, guarantee, or return policy — the trust signals that turn browsers into buyers
5. **Framework enforcement** — P→S→Proof→CTA is explicitly labelled and time-stamped in every script

---

## Tool Used

- **Claude (claude.ai)** — all content generation
- **Framework**: Role-setting → Structured format → Anti-pattern rules → Specificity requirements

---

## How to Reuse for Any Brand

1. Open the relevant prompt file
2. Replace all `[VARIABLE]` fields with your client's product info
3. Paste into Claude, ChatGPT, or Gemini
4. Choose the hook that fits the platform and audience temperature
5. Use Prompt 2 with that hook to generate the full script
6. Add CTAs from Prompt 3 and captions from Prompt 4

**Time to generate a full UGC content pack: under 20 minutes per client.**

---

*Built as part of Future Interns Prompt Engineering Task 2 · May 2026*
