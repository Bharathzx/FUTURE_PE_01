# Prompt 2 — Full UGC Ad Script

## Purpose
Generates a complete, time-coded UGC video ad script following the Problem → Solution → Proof → CTA framework. Output is ready for a creator to read from.

## Prompt Template

```
You are a UGC scriptwriter. Write a full short-form ad script using the 
Problem → Solution → Proof → CTA framework.

Product: [PRODUCT_NAME]
Brand: [BRAND_NAME]
Platform: [Instagram Reel / YouTube Short / Story Ad]
Duration: [15s / 30s / 60s]
Hook to use: [PASTE ONE HOOK FROM PROMPT 1 OUTPUT]
Target audience: [AUDIENCE]
Price: [PRICE]
Key differentiator: [WHAT MAKES THIS PRODUCT DIFFERENT FROM COMPETITORS]
Proof point: [RESULT — e.g., "visible difference in 3 weeks"]
Offer: [DISCOUNT / FREE TRIAL / RETURN POLICY]

Script format — label each section with timestamps:
[0–3s]   HOOK
[3–Xs]   PROBLEM (relatable, specific, personal)
[X–Xs]   SOLUTION (product reveal, key feature or ingredient)
[X–Xs]   PROOF (visual result, stat, or testimonial)
[X–Xs]   CTA (one clear action, low-friction)

Rules:
- Word count must match duration (2.5 words/second for spoken speech)
  → 15s ≈ 37 words | 30s ≈ 75 words | 60s ≈ 150 words
- Write as spoken dialogue — not ad copy. Read it aloud; it should sound natural.
- No superlatives ("best ever", "unbelievable"). Be specific instead.
- Problem section: describe a feeling or situation the audience recognises, not just a product feature
- CTA must include at least one risk-reducer: price, return policy, or social proof number
- The word "just" can appear maximum once
- Avoid: "life-changing", "game-changer", "obsessed", "incredible", "holy grail"
```

## Variables to Replace

| Variable | GlowBar Example |
|----------|----------------|
| `[PRODUCT_NAME]` | Vitamin C Serum |
| `[BRAND_NAME]` | GlowBar |
| `[PLATFORM]` | Instagram Reel |
| `[DURATION]` | 30s |
| `[HOOK]` | "I was spending ₹3,000 on foundation every month just to cover my dark spots. Then I tried this." |
| `[AUDIENCE]` | Women 22–35, pigmentation concerns |
| `[PRICE]` | ₹599 |
| `[KEY DIFFERENTIATOR]` | 15% L-ascorbic acid (clinically active form) + Vitamin E + ferulic acid |
| `[PROOF POINT]` | Dark spots visibly lighter within 3–4 weeks |
| `[OFFER]` | 30-day return policy, ships in 48 hours |

## Follow-up Prompt (optional)

```
Now rewrite this script for [NEW PLATFORM] with a [SHORTER/LONGER] duration of [Xs].
Keep the same hook and product details but adjust:
- Pacing (faster / more detail)
- Which section gets cut or expanded
- CTA tone (more urgent / softer)
```
