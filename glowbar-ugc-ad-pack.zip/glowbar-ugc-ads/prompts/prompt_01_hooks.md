# Prompt 1 — Hook Generator

## Purpose
Generates 6 unique opening hooks for UGC-style short-form video ads. Hooks are the first 1–3 spoken lines; they determine whether someone stops scrolling.

## Prompt Template

```
You are a UGC ad scriptwriter who specialises in high-converting short-form content for D2C brands.

Generate 6 different hooks (opening 1–3 lines) for a UGC-style Instagram Reel ad for:

Product: [PRODUCT_NAME]
Brand: [BRAND_NAME]
Key benefit: [PRIMARY_BENEFIT]
Target audience: [AUDIENCE — age, gender, pain point]
Price: [PRICE]

For each hook, write:
- The hook text (as if spoken directly to camera, max 2 sentences)
- The emotional trigger it uses (pain / curiosity / social proof / FOMO / humour / contrarian)
- The tone (confessional / surprised / bold / lighthearted / authoritative)

Rules:
- Sound like a real person talking, NOT a brand
- No buzzwords: "game-changer", "life-changing", "obsessed", "holy grail"
- Hook must create a reason to keep watching — a problem, a question, or a surprising claim
- Write in first person
- Hooks 1–2 should target cold audience (new awareness)
- Hooks 3–4 should target warm audience (consideration)
- Hooks 5–6 should be direct / benefit-focused (hot / retargeting audience)
```

## Variables to Replace

| Variable | GlowBar Example |
|----------|----------------|
| `[PRODUCT_NAME]` | Vitamin C Serum |
| `[BRAND_NAME]` | GlowBar |
| `[PRIMARY_BENEFIT]` | Fades dark spots and pigmentation in 4–6 weeks |
| `[AUDIENCE]` | Women 22–35, Indian, dealing with pigmentation and uneven skin tone |
| `[PRICE]` | ₹599 |

## Follow-up Prompt (optional)

```
Take Hook [NUMBER] and rewrite it in 3 variations:
1. More vulnerable / personal
2. More bold / contrarian
3. Shorter — under 10 words, maximum punch

Keep the same emotional trigger but change the angle.
```
