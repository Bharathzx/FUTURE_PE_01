# Prompt 4 — Caption Writer

## Purpose
Generates 3 platform-adapted captions: a long-form Reel caption, a short Story/feed caption, and a YouTube Shorts description.

## Prompt Template

```
Write 3 captions for a UGC-style ad post for [BRAND_NAME]'s [PRODUCT_NAME].

---

CAPTION 1 — Long-form, conversational (Instagram Reels)
- Length: 150–200 words
- Structure: personal situation → problem → discovered the product → result → soft CTA
- End with 10–12 relevant hashtags
- Tone: [TONE]
- CRITICAL: The first line must work as a standalone hook before "...more"
  (Instagram shows only ~125 characters before truncating)

CAPTION 2 — Short and punchy (Instagram Stories paid ad / feed post)
- Length: max 4 lines, ~50 words
- Structure: problem → solution → CTA
- No hashtags
- One clear action at the end

CAPTION 3 — Educational description (YouTube Shorts)
- Length: 80–100 words
- Include: what the video covers, a brief "why I made this" line, and timestamps
- End with a link CTA
- Tone: helpful, informative, personal

---

Product info:
- Product: [PRODUCT_NAME]
- Brand: [BRAND_NAME]
- Key benefit: [BENEFIT]
- Price: [PRICE]
- Offer: [OFFER]
- Audience: [TARGET AUDIENCE]
- Tone: [TONE — e.g., honest and casual / educational / playful]

Rules:
- First line of Caption 1 must be max 125 characters (Instagram preview limit)
- Caption 1 hashtags: mix niche tags (under 500k posts) and broad tags (over 1M)
- Max 12 hashtags — quality over volume
- Avoid hashtag dumps unrelated to the product
- Sound like the creator's own words, not the brand's press release
```

## Variables to Replace

| Variable | GlowBar Example |
|----------|----------------|
| `[PRODUCT_NAME]` | Vitamin C Serum |
| `[BRAND_NAME]` | GlowBar |
| `[BENEFIT]` | Fades dark spots and pigmentation in 4–6 weeks |
| `[PRICE]` | ₹599 |
| `[OFFER]` | 30-day returns + 10% off first order |
| `[TARGET AUDIENCE]` | Indian women 22–35 with pigmentation / uneven skin tone |
| `[TONE]` | honest, casual, relatable — like texting a friend |

## Follow-up Prompt (optional)

```
Rewrite Caption 1 in [REGIONAL LANGUAGE — e.g., Hindi / Tamil / Telugu].
Keep the same story arc and product details.
Use natural, colloquial language — not a direct translation.
End with the same hashtags in English.
```
