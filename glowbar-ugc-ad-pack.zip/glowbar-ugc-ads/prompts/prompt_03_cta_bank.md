# Prompt 3 — CTA Bank Generator

## Purpose
Generates 12 ready-to-use calls to action across 4 audience intent levels. Can be used as spoken lines, on-screen text, or in captions.

## Prompt Template

```
Generate 12 unique calls-to-action (CTAs) for a UGC ad campaign for 
[BRAND_NAME]'s [PRODUCT_NAME].

Organise them into 4 groups of 3:

Group 1 — Low-friction (cold audience, first touchpoint)
  Goal: reduce risk, invite exploration, no pressure

Group 2 — Urgency-based (warm audience, scarcity or time-sensitivity)
  Goal: prompt action now, not later

Group 3 — Social proof (mid-funnel, validation-seeking audience)
  Goal: show that others have already decided

Group 4 — Soft engagement (organic content, build community / DMs)
  Goal: increase comments, saves, DMs without asking for a purchase

For each CTA:
- Write the CTA text as it would be spoken (not read as copy)
- Mark format: [spoken] / [on-screen text] / [caption]

Offer details to reference where relevant:
- Price: [PRICE]
- Return policy: [RETURN POLICY]
- Current offer: [OFFER — e.g., 10% off first order]
- Social proof: [NUMBER — e.g., 40,000 customers / 4.8 stars]

Rules:
- Sound authentic, not salesy
- Never use: "What are you waiting for?", "Don't miss out!", "Limited time only", "Click the link below"
- Each CTA must be specific: name the price, OR the guarantee, OR the result — not vague
- Group 4 CTAs must feel like a human asking, not a brand prompting engagement
```

## Variables to Replace

| Variable | GlowBar Example |
|----------|----------------|
| `[BRAND_NAME]` | GlowBar |
| `[PRODUCT_NAME]` | Vitamin C Serum |
| `[PRICE]` | ₹599 |
| `[RETURN POLICY]` | 30-day returns, no questions asked |
| `[OFFER]` | 10% off first order with code GLOW10 |
| `[SOCIAL PROOF]` | 40,000+ customers, 4.8 stars across 8,000+ reviews |
